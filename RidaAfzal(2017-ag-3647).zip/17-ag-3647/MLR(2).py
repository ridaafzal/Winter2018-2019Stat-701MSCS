import numpy as np
import matplotlib.pyplot as plt
X1 = np.array([40,50,60,18,10,6]) #X1 for No. of statement
print(" X1 = ", X1)
X2 = np.array([30,40,50,11,10,2])     #X2 for exection time/printing time
print(" X2 = ", X2)
Y = np.array([5,8,10,2,1,1])    #Y for no, of pages
print(" Y = ", Y)
MeanX1 = sum(X1) / len(X1)
print(" Mean of X1 = ", MeanX1)
MeanX2 = sum(X2) / len(X2)
print(" Mean of X2 = ", MeanX2)
MeanY = sum(Y) / len(Y)
print(" Mean of Y = ", MeanY)
x1= (X1 - MeanX1)
print("value of x1 =", x1)
x2 = (X2 - MeanX2)
print("value of x2 =", x2)
y = (Y - MeanY)
print("value of y =", y)
x1square=x1*x1
print("square of x1", x1square)
x2square=x2*x2
print("square of x2", x2square)
ysquare=y*y
print("square of y", ysquare)
a=sum(x1square)
print("sum of x1", a)
b=sum(x2square)
print("sum of x2", b)
c=sum(ysquare)
print("sum of y", c)
x1x2=x1*x2
d=sum(x1x2)
print("sum of x1x2", d)
x1y=x1*y
e=sum(x1y)
print("sum of x1y", e)
x1x2=x1*x2
g=sum(x1x2)
print("sum of x1x2", g)
x2y=x2*y
f=sum(x2y)
print("sum of x2y", f)
B1=((e*b)-(d*f))/((a*b)-(g*g))
print("value of B1", B1)
B2=((f*a)-(e*g))/((a*b)-(g*g))
print("value of B2", B2)
B0=MeanY-B1*(MeanX1)-B2*(MeanX2)
print("value of Bo", B0)
plt.scatter(X1, Y, color="g", marker="o", s=30)    #for X1,Y
plt.plot(X1, Y, color="b")
plt.xlabel('X1')
plt.ylabel('Y')
plt.plot()
plt.show()
plt.scatter(X2, Y, color="g", marker="o", s=30)   #for X2,Y
plt.plot(X2, Y, color="b")
plt.xlabel('X2')
plt.ylabel('Y')
plt.plot()
plt.show()
TSS=sum((Y - MeanY)*(Y-MeanY))
print(TSS)